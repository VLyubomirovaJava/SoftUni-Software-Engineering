import java.util.*;

public class MathOperation {

    public int add(int i, int i1) {
   return i +i1;
    }
    public int add(int i, int i1, int i2) {
        return i +i1 + i2;
    }
    public int add(int i, int i1, int i2, int i3) {
        return i +i1 +i2 + i3;
    }
}
