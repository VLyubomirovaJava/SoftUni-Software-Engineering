package vehicleShop.models.tool;

public interface Tool {
    int getPower();

    void decreasesPower();

    boolean isUnfit();
}
