package vehicleShop.models.worker;

import java.util.*;

public class FirstShift extends BaseWorker {
    private  static final int STR_FIRST = 100;


    public FirstShift(String name) {
        super(name, STR_FIRST);
    }
}
