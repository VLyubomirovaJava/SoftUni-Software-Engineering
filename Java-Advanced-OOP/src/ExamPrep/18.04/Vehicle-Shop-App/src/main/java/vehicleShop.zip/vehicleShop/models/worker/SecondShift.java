package vehicleShop.models.worker;

import java.util.*;

public class SecondShift extends BaseWorker {
    private  static final int STR_SECOND = 70;


    public SecondShift(String name) {
        super(name, STR_SECOND);
    }
}
