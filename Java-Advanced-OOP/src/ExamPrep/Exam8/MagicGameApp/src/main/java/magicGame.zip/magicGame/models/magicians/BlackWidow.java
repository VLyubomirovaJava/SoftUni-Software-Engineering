package magicGame.models.magicians;

import magicGame.models.magics.Magic;

import java.util.*;

public class BlackWidow extends MagicianImpl {
//checked

    public BlackWidow(String username, int health, int protection, Magic magic) {
        super(username, health, protection, magic);
    }
}
