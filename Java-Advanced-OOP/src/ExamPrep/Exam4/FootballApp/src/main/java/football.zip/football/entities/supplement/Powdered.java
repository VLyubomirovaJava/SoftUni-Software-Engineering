package football.entities.supplement;
public class Powdered extends BaseSupplement {
private final static int ENERGY_POWDERED=120;
private final static double PRICE_POWDERED=15;

    public Powdered() {
        super(ENERGY_POWDERED, PRICE_POWDERED);
    }
}
