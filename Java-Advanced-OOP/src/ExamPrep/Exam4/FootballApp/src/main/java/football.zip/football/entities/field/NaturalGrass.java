package football.entities.field;

public class NaturalGrass extends  BaseField{
    private final static int NATURAL_CAPACITY = 250;
    public NaturalGrass(String name) {
        super(name, NATURAL_CAPACITY);
    }
}



