package cats;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class HouseTests {
    private House house;
    @Before
    public void setUp() {
        house = new House("My House", 2);
    }

    @Test
    public void testGetName() {
        Assert.assertEquals("My House", house.getName());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameNull() {
        house = new House(null, 2);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameEmpty() {
        house = new House("", 2);
    }

    @Test
    public void testGetCapacity() {
        Assert.assertEquals(2, house.getCapacity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityNegative() {
        house = new House("My House", -1);
    }

    @Test
    public void testAddCat() {
        Cat cat = new Cat("Whiskers");
        house.addCat(cat);
        Assert.assertEquals(1, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCatFullHouse() {
        Cat cat1 = new Cat("Whiskers");
        Cat cat2 = new Cat("Fluffy");
        Cat cat3 = new Cat("Mittens");
        house.addCat(cat1);
        house.addCat(cat2);
        house.addCat(cat3);
    }

    @Test
    public void testRemoveCat() {
        Cat cat = new Cat("Whiskers");
        house.addCat(cat);
        house.removeCat("Whiskers");
        Assert.assertEquals(0, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveCatNotExist() {
        house.removeCat("Whiskers");
    }

    @Test
    public void testCatForSale() {
        Cat cat = new Cat("Whiskers");
        house.addCat(cat);
        Cat soldCat = house.catForSale("Whiskers");
        Assert.assertFalse(soldCat.isHungry());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCatForSaleNotExist() {
        house.catForSale("Whiskers");
    }

    @Test
    public void testStatistics() {
        Cat cat1 = new Cat("Whiskers");
        Cat cat2 = new Cat("Fluffy");
        house.addCat(cat1);
        house.addCat(cat2);
        Assert.assertEquals("The cat Whiskers, Fluffy is in the house My House!", house.statistics());
    }
}