package glacialExpedition.models.explorers;

import java.util.*;

public class GlacierExplorer extends BaseExplorer {
    private final static double  ENERGY_GLACIER = 40;
    public GlacierExplorer(String name) {
        super(name, ENERGY_GLACIER);
    }


    }
