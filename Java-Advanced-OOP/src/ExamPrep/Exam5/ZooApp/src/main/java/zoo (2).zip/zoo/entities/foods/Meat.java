package zoo.entities.foods;

import java.util.*;

public class Meat extends BaseFood {
    private final static int CALORIES_MEAT=70;
    private final static double PRICE_MEAT=10;

    public Meat() {
        super(CALORIES_MEAT,PRICE_MEAT);
    }
}



