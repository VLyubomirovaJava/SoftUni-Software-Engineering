package com.example.springintro1.model.entity;

public enum AgeRestriction {
    MINOR,TEEN,ADULT
}
