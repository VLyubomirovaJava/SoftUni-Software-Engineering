package com.example.springintro1.model.entity;

public enum EditionType {
    NORMAL,PROMO,GOLD
}
