import java.util.ArrayList;
import java.util.List;

public class Box<T extends Comparable<T>> {
    private List<T> values;

    public Box() {
        this.values = new ArrayList<>();
    }
    public int compareWhichIsGreater( T element){
      return (int) values.stream().filter(e -> e.compareTo(element)>0)
                .count();
        }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        for (T element : values) {
            //getting the type of value we have while printing
            sb.append(element.getClass().getName() + ": " + element).append("\n");
        }
        return sb.toString();
    }

    public void add(T text) {
        values.add(text);
    }
}
