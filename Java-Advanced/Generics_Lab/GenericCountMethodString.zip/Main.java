import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        Box<String> StringBox = new Box<>();
        for (int i = 0; i < n; i++) {
            String text = scanner.nextLine();
            StringBox.add(text);
        }
        String textToCompare = scanner.nextLine();
        System.out.println(StringBox.compareWhichIsGreater(textToCompare));

    }
}