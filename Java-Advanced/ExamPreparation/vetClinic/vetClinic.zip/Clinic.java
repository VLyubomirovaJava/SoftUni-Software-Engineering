package vetClinic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Clinic {
    private int capacity;
    private List<Pet> petsInfo;


    public Clinic(int capacity) {
        this.capacity = capacity;
        this.petsInfo =new ArrayList<>();
    }
    public void add(Pet pet){
        if (petsInfo.size() < capacity){
            this.petsInfo.add(pet);
        }
    }
    public boolean remove(String name){

        return petsInfo.removeIf(pet -> pet.getName().equals(name));
    }
    public Pet getPet(String name, String owner){
        for (Pet pet : petsInfo) {
            if (pet.getName().equals(name) && pet.getOwner().equals(owner)){
                return pet;
            }
        }
        return null;
    }
    public Pet getOldestPet(){
        return petsInfo.stream().max(Comparator.comparingInt(Pet::getAge)).orElse(null);
    }
    public int getCount(){
        return petsInfo.size();
    }

    public String getStatistics(){
        StringBuilder output = new StringBuilder();
        output.append("The clinic has the following patients:");

        for (Pet pet :petsInfo) {
            output.append(System.lineSeparator());
            output.append(String.format("%s %s",pet.getName(),pet.getOwner()));
        }
        return output.toString();
    }
    @Override
    public String toString(){
        return super.toString();
    }
}

