import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
StackOfStrings stack = new StackOfStrings(new ArrayList<>());
stack.push("one");
stack.push("two");
stack.push("three");
        System.out.println(stack.isEmpty());
        System.out.println(stack.peek());
    }
}
