import java.util.*;

public class Lizard extends Reptile {
    public Lizard() {
    }
}
