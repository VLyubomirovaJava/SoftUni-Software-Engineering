import java.util.*;

public class Reptile extends Animal {
    public Reptile() {
    }
}
