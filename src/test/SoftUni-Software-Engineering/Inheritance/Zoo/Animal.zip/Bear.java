import java.util.*;

public class Bear extends Mammal {
    public Bear() {
    }
}
