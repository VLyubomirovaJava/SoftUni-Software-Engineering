import java.util.*;

public class Gorilla extends Mammal {
    public Gorilla() {
    }
}
