import java.util.*;

public class Mammal extends Animal {
    public Mammal() {
    }
}
