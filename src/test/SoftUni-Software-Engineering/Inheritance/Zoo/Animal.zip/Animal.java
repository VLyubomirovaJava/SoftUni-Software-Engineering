import java.util.*;

public class Animal {
private String name;


    public String getName() {
        return name;
    }
}
