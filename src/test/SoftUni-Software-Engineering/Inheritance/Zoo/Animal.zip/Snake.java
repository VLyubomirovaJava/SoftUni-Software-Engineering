import java.util.*;

public class Snake extends Reptile {
    public Snake() {
    }
}
