package hero;

import java.util.*;

public class DarkWizard extends Wizard {

    public DarkWizard(String username, int level) {
        super(username, level);
    }
}
