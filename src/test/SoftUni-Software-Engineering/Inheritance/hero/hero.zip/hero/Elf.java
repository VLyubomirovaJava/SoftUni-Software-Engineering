package hero;

import java.util.*;

public class Elf extends Hero {
    public Elf(String username, int level) {
        super(username, level);
    }
}
