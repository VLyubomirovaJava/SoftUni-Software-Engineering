import java.math.BigDecimal;
import java.util.*;

public class ColdBeverage extends Beverage {

    public ColdBeverage(String name, BigDecimal price, double milliliters) {
        super(name, price, milliliters);
    }
}
