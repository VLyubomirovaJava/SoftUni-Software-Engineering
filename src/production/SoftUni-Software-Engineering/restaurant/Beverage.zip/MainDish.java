import java.math.BigDecimal;
import java.util.*;

public class MainDish extends Food {


    public MainDish(String name, BigDecimal price, double grams) {
        super(name, price, grams);
    }
}
