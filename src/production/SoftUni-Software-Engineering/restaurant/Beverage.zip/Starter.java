import java.math.BigDecimal;
import java.util.*;

public class Starter extends Food{


    public Starter(String name, BigDecimal price, double grams) {
        super(name, price, grams);
    }
}
